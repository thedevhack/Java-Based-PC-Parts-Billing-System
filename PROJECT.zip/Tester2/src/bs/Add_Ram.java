package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_Ram extends JFrame {

	private JPanel contentPane;
	private JTextField txtramname;
	private JTextField txtramprice;

	/**
	 * Launch the application.
	 */
	static Connection connection = null;
	public static void intialization() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Ram frame = new Add_Ram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Ram() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ram Name");
		lblNewLabel.setBounds(29, 68, 79, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Ram Price");
		lblNewLabel_1.setBounds(29, 129, 64, 20);
		contentPane.add(lblNewLabel_1);
		
		txtramname = new JTextField();
		txtramname.setBounds(118, 68, 244, 20);
		contentPane.add(txtramname);
		txtramname.setColumns(10);
		
		txtramprice = new JTextField();
		txtramprice.setBounds(118, 129, 244, 20);
		contentPane.add(txtramprice);
		txtramprice.setColumns(10);
		
		JButton btnsubmitRAM = new JButton("SUBMIT");
		btnsubmitRAM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				intialization();
				try {
					String ram_insert = "insert into rams values(?,?)";
					PreparedStatement statement = connection.prepareStatement(ram_insert);
					statement.setString(1, txtramname.getText());
					statement.setString(2, txtramprice.getText());
					int data_entered = statement.executeUpdate();
					if(data_entered > 0)
					{
						 JOptionPane.showMessageDialog(null,"Data Inserted Succesfully");
					}else {
						 JOptionPane.showMessageDialog(null,"Unable to insert data");

					}
					
					
					} catch (Exception e) {
					// TODO: handle exception
				}
			}
		});
		btnsubmitRAM.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnsubmitRAM.setContentAreaFilled(false);
		btnsubmitRAM.setBounds(156, 197, 145, 23);
		contentPane.add(btnsubmitRAM);
	}

}
