package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_MotherBoard extends JFrame {

	private JPanel contentPane;
	private JTextField txtmotherboardname;
	private JTextField txtmotherboardprice;

	/**
	 * Launch the application.
	 */
	static Connection connection = null;
	public static void intialization() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_MotherBoard frame = new Add_MotherBoard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_MotherBoard() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("MotherBoard Name");
		lblNewLabel.setBounds(30, 59, 114, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblMotherboardPrice = new JLabel("MotherBoard Price");
		lblMotherboardPrice.setBounds(30, 123, 114, 14);
		contentPane.add(lblMotherboardPrice);
		
		txtmotherboardname = new JTextField();
		txtmotherboardname.setBounds(186, 56, 183, 20);
		contentPane.add(txtmotherboardname);
		txtmotherboardname.setColumns(10);
		
		txtmotherboardprice = new JTextField();
		txtmotherboardprice.setBounds(186, 120, 183, 20);
		contentPane.add(txtmotherboardprice);
		txtmotherboardprice.setColumns(10);
		
		JButton btnsubmitmotherboard = new JButton("SUBMIT");
		btnsubmitmotherboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				intialization();
				try {
					String motherboard_insert = "insert into motherboards values(?,?)";
					PreparedStatement statement = connection.prepareStatement(motherboard_insert);
					statement.setString(1, txtmotherboardname.getText());
					statement.setString(2, txtmotherboardprice.getText());
					int data_entered = statement.executeUpdate();
					if(data_entered > 0)
					{
						 JOptionPane.showMessageDialog(null,"Data Inserted Succesfully");
					}else {
						 JOptionPane.showMessageDialog(null,"Unable to insert data");

					}
					
					
					} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		btnsubmitmotherboard.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnsubmitmotherboard.setContentAreaFilled(false);
		btnsubmitmotherboard.setBounds(142, 192, 123, 31);
		contentPane.add(btnsubmitmotherboard);
	}

}
