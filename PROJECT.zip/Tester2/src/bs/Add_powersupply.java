package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.omg.PortableServer.ServantRetentionPolicyValue;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_powersupply extends JFrame {

	private JPanel contentPane;
	private final JTextField txtpowersupplyname = new JTextField();
	private JTextField txtpowersupplyprice;

	/**
	 * Launch the application.
	 */
	static Connection connection = null;
	public static void intialization() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_powersupply frame = new Add_powersupply();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_powersupply() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Power Supply Name");
		lblNewLabel.setBounds(33, 48, 114, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Power Supply Price");
		lblNewLabel_1.setBounds(33, 112, 102, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				intialization();
				try {
					String psu_insert = "insert into powersupply values(?,?)";
					PreparedStatement statement = connection.prepareStatement(psu_insert);
					statement.setString(1, txtpowersupplyname.getText());
					statement.setString(2, txtpowersupplyprice.getText());
					int data_entered = statement.executeUpdate();
					if(data_entered > 0)
					{
						 JOptionPane.showMessageDialog(null,"Data Inserted Succesfully");
					}else {
						 JOptionPane.showMessageDialog(null,"Unable to insert data");

					}
					
					
					} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBounds(173, 172, 89, 23);
		contentPane.add(btnNewButton);
		txtpowersupplyname.setBounds(157, 44, 248, 23);
		contentPane.add(txtpowersupplyname);
		txtpowersupplyname.setColumns(10);
		
		txtpowersupplyprice = new JTextField();
		txtpowersupplyprice.setBounds(157, 109, 248, 20);
		contentPane.add(txtpowersupplyprice);
		txtpowersupplyprice.setColumns(10);
	}

}
