package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Color;

import keeptoo.Drag;
import keeptoo.KGradientPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import keeptoo.KButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.sql.StatementEvent;
import javax.swing.ImageIcon;
import java.awt.Component;
import javax.swing.JPasswordField;

public class Signup_signin extends JFrame {

	private JPanel contentPane;
	private JTextField username_field;
	private JPasswordField password_field;

	/**
	 * Launch the application.
	 */
	Connection connection = null;
	public void createTableNew() {
		try {
			DatabaseMetaData dmd = connection.getMetaData();
			ResultSet set = dmd.getTables(null, null, "USERTABLE", null);
			
			if(set.next()) {
				
			}else {
				String createtable = "create table USERTABLE ("
						            + "name varchar(20), "
						            + "username varchar(20), "
						            + "password varchar(20), "
						            + "organization varchar(20), "
						            + "mobile varchar(11))";
				
				PreparedStatement statement = connection.prepareStatement(createtable);
				statement.executeUpdate();
				JOptionPane.showMessageDialog(null, "Table Created Successfully");
			}
		} catch (Exception e) {
			System.out.print("Error: " + e.getMessage()); 
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup_signin frame = new Signup_signin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void intialize() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public Signup_signin() {
		intialize();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 719, 637);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 719, 637);
		contentPane.add(panel);
		panel.setLayout(null);
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setBounds(0, 0, 719, 639);
		panel.add(gradientPanel);
		gradientPanel.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		gradientPanel.kEndColor = new Color(0, 255, 255);
		gradientPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				new Drag(gradientPanel).onPress(arg0);
			}
		});
		gradientPanel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				new Drag(gradientPanel).moveWindow(arg0);
			}
		});
		gradientPanel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				
			}
		});
		gradientPanel.kGradientFocus = 300;
		gradientPanel.setkGradientFocus(600);
		gradientPanel.setkEndColor(new Color(51, 153, 255));
		gradientPanel.setLayout(null);
		
		username_field = new JTextField();
		username_field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		username_field.setForeground(new Color(255, 255, 255));
		username_field.setCaretColor(new Color(102, 153, 204));
		username_field.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(255, 255, 255)));
		username_field.setOpaque(false);
		username_field.setBounds(178, 258, 313, 31);
		gradientPanel.add(username_field);
		username_field.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setForeground(Color.LIGHT_GRAY);
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(178, 213, 77, 25);
		gradientPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setForeground(Color.LIGHT_GRAY);
		lblNewLabel_1.setBounds(188, 318, 64, 19);
		gradientPanel.add(lblNewLabel_1);
		
		KButton btnSubmit = new KButton();
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String validate = "select * from USERTABLE where username=? and password=?";
					PreparedStatement statement = connection.prepareStatement(validate);
					statement.setString(1, username_field.getText());
					statement.setString(2, password_field.getText());
					ResultSet set = statement.executeQuery();
					if(set.next())
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						new Dashboard().setVisible(true);
						
					}else {
						JOptionPane.showMessageDialog(null, "Invlid Username Or Password");
					}
					
					
					
				} catch (Exception e) {
					// TODO: handle exception
				}
				
				
				
				
			}
		});
		btnSubmit.setBorderPainted(false);
		btnSubmit.setkHoverForeGround(new Color(255, 51, 255));
		btnSubmit.kFillButton = false;
		btnSubmit.setkFillButton(false);
		btnSubmit.setOpaque(false);
		btnSubmit.kStartColor = new Color(255, 51, 204);
		btnSubmit.kHoverForeGround = new Color(255, 51, 255);
		btnSubmit.kHoverEndColor = new Color(0, 255, 255);
		btnSubmit.setkHoverEndColor(new Color(0, 255, 255));
		btnSubmit.setkEndColor(new Color(102, 51, 153));
		btnSubmit.kBorderRadius = 40;
		btnSubmit.kEndColor = new Color(102, 51, 153);
		btnSubmit.setkStartColor(new Color(0, 255, 255));
		btnSubmit.setText("SignIn");
		btnSubmit.setBounds(178, 423, 128, 31);
		gradientPanel.add(btnSubmit);
		
		JLabel lblOr = new JLabel("or");
		lblOr.setForeground(new Color(204, 204, 204));
		lblOr.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOr.setBounds(336, 425, 28, 22);
		gradientPanel.add(lblOr);
		
		KButton btnSignup = new KButton();
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String insert_data = "insert into USERTABLE(username,password) values(?,?)";
				try {
					PreparedStatement statement = connection.prepareStatement(insert_data);
					statement.setString(1, username_field.getText());
					statement.setString(2, password_field.getText());
					int data = statement.executeUpdate();
					if(data>0) {
						JOptionPane.showMessageDialog(null, "Data Inseted Successfully");
					}
					else {
						JOptionPane.showMessageDialog(null, "Unable To Insert Data");

					}
				} catch (Exception e) {

					// TODO: handle exception
				}
			}
		});
		btnSignup.setBorderPainted(false);
		btnSignup.setText("SignUp");
		btnSignup.setOpaque(false);
		btnSignup.kStartColor = new Color(255, 51, 204);
		btnSignup.setkStartColor(new Color(255, 51, 204));
		btnSignup.kHoverForeGround = new Color(255, 51, 255);
		btnSignup.setkHoverForeGround(new Color(255, 51, 255));
		btnSignup.kHoverEndColor = Color.CYAN;
		btnSignup.setkHoverEndColor(Color.CYAN);
		btnSignup.kFillButton = false;
		btnSignup.setkFillButton(false);
		btnSignup.kEndColor = new Color(102, 51, 153);
		btnSignup.setkEndColor(new Color(102, 51, 153));
		btnSignup.kBorderRadius = 40;
		btnSignup.setkBorderRadius(40);
		btnSignup.setBounds(380, 423, 128, 31);
		gradientPanel.add(btnSignup);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblX.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblX.setForeground(Color.LIGHT_GRAY);
		lblX.setHorizontalTextPosition(SwingConstants.CENTER);
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setBounds(684, 0, 34, 31);
		gradientPanel.add(lblX);
		
		JLabel label = new JLabel("");
		label.setHorizontalTextPosition(SwingConstants.CENTER);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setIcon(new ImageIcon(Signup_signin.class.getResource("/icons/if_user_925901 (1).png")));
		label.setBounds(290, 86, 140, 93);
		gradientPanel.add(label);
		
		password_field = new JPasswordField();
		password_field.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		password_field.setCaretColor(Color.MAGENTA);
		password_field.setBorder(new MatteBorder(0, 0, 2, 0, (Color) Color.WHITE));
		password_field.setOpaque(false);
		password_field.setBounds(178, 356, 313, 20);
		gradientPanel.add(password_field);
		setUndecorated(true);
		createTableNew();
	}
}
