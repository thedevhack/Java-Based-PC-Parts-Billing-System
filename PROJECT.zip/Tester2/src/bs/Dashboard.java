package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.Color;
import javax.swing.JButton;
import javax.naming.spi.DirStateFactory.Result;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Component;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.CardLayout;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import java.awt.ScrollPane;
import java.awt.Cursor;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import keeptoo.KGradientPanel;

public class Dashboard extends JFrame {

	private JPanel contentPane;
	private JPanel pnlquickbill;
	private JPanel pnladdproducts;
	private JLayeredPane layeredPane;
	private JTextField price_cpu;
	private JTextField price_ram;
	private JTextField price_psu;
	private JTextField price_gpu;
	private JTextField price_hdd;
	private JTextField price_motherboard;
	private JLabel show_total;
	private JComboBox motheroard_combobox;
	private JComboBox hdd_combobox;
	private JComboBox gpu_combobox;
	private JComboBox psu_combobox;
	private JComboBox ram_combobox;
	private JComboBox cpu_combobox;

	/**
	 * Launch the application.
	 */
	Connection conn = null;
	private JLabel DB_STATUS;
	private void dropdownprocessor() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");
			DB_STATUS.setBackground(new  Color(51,255,0));
			

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
			DB_STATUS.setBackground(new  Color(255,51,0));

		}
		String processor = "select * from processors";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(processor);
			while(set.next()) {
				cpu_combobox.addItem(set.getString("Processor"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void dropdownram() {
		String ram = "select * from rams";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(ram);
			while(set.next()) {
				ram_combobox.addItem(set.getString("RAM"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void dropdownmotherboard() {
		String motherboard = "select * from motherboards";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(motherboard);
			while(set.next()) {
				motheroard_combobox.addItem(set.getString("MotherBoard"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void dropdownhdd() {
		String hdd = "select * from harddrives";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(hdd);
			while(set.next()) {
			 hdd_combobox.addItem(set.getString("HardDrives"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void dropdownpowersupply() {
		String psu = "select * from powersupply";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(psu);
			while(set.next()) {
			 psu_combobox.addItem(set.getString("PowerSupply"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void dropdowngpu() {
		String gpu = "select * from gpu";
		try {
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(gpu);
			while(set.next()) {
			 gpu_combobox.addItem(set.getString("GPU"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
	
			public void run() {
				try {
					Dashboard frame = new Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void switchpanels(JPanel panel) {
		layeredPane.removeAll();
		layeredPane.add(panel);
		layeredPane.repaint();
		layeredPane.revalidate();
	}
	public Dashboard() {
		setName("dashboard");
		setMinimumSize(new Dimension(1000, 600));
		setMaximumSize(new Dimension(1000, 600));
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setName("Logout");
		contentPane.setOpaque(false);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel dashboard = new JPanel();
		dashboard.setName("Logout");
		dashboard.setAlignmentY(Component.TOP_ALIGNMENT);
		dashboard.setBounds(0, 0, 1000, 208);
		contentPane.add(dashboard);
		dashboard.setBackground(new Color(51, 102, 204));
		dashboard.setLayout(null);
		
		JLabel lblYouHeeLogin = new JLabel("You Are Logged In");
		lblYouHeeLogin.setForeground(new Color(255, 255, 255));
		lblYouHeeLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblYouHeeLogin.setBounds(747, 41, 150, 22);
		dashboard.add(lblYouHeeLogin);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_user_925901 (1).png")));
		lblNewLabel.setBounds(915, 11, 63, 64);
		dashboard.add(lblNewLabel);
		
		JLabel lbladdproducts = new JLabel("");
		lbladdproducts.setOpaque(true);
		lbladdproducts.setBackground(new Color(51, 0, 255));
		lbladdproducts.setForeground(new Color(255, 255, 255));
		lbladdproducts.setHorizontalAlignment(SwingConstants.CENTER);
		lbladdproducts.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 24));
		lbladdproducts.setBounds(66, 194, 234, 14);
		dashboard.add(lbladdproducts);
		
		JLabel lblquickbill = new JLabel("");
		lblquickbill.setBackground(new Color(255, 255, 255));
		lblquickbill.setOpaque(true);
		lblquickbill.setForeground(new Color(204, 0, 255));
		lblquickbill.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblquickbill.setBounds(365, 194, 278, 14);
		dashboard.add(lblquickbill);
		
		JButton btnAddProducts = new JButton("ADD PRODUCTS");
		btnAddProducts.setForeground(new Color(255, 255, 255));
		btnAddProducts.setFocusable(false);
		btnAddProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lbladdproducts.setBackground(new Color(51, 0, 255));
				lblquickbill.setBackground(new Color(255, 255, 255));
				switchpanels(pnladdproducts);

			}
		});
		btnAddProducts.setBorder(null);
		btnAddProducts.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAddProducts.setMinimumSize(new Dimension(117, 25));
		btnAddProducts.setMaximumSize(new Dimension(117, 25));
		btnAddProducts.setPreferredSize(new Dimension(117, 25));
		btnAddProducts.setContentAreaFilled(false);
		btnAddProducts.setFont(new Font("Arial", Font.BOLD, 14));
		btnAddProducts.setBounds(66, 168, 234, 29);
		dashboard.add(btnAddProducts);
		
		JButton btnQuickBill = new JButton("QUICK BILL");
		btnQuickBill.setForeground(new Color(255, 255, 255));
		btnQuickBill.setFocusable(false);
		btnQuickBill.setBorder(null);
		btnQuickBill.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnQuickBill.setPreferredSize(new Dimension(117, 25));
		btnQuickBill.setMinimumSize(new Dimension(117, 25));
		btnQuickBill.setMaximumSize(new Dimension(117, 25));
		btnQuickBill.setFont(new Font("Arial", Font.BOLD, 14));
		btnQuickBill.setContentAreaFilled(false);
		btnQuickBill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblquickbill.setBackground(new Color(51, 0, 255));
				lbladdproducts.setBackground(new Color(255, 255, 255));
				switchpanels(pnlquickbill);
			}
		});
		btnQuickBill.setBounds(365, 168, 278, 29);
		dashboard.add(btnQuickBill);
		
		JLabel titledashboard = new JLabel("A PLACE WHERE YOU BUILD BEFORE YOU ACTUALLY BUILD");
		titledashboard.setHorizontalAlignment(SwingConstants.CENTER);
		titledashboard.setForeground(new Color(255, 255, 255));
		titledashboard.setFont(new Font("Vijaya", Font.BOLD, 17));
		titledashboard.setBackground(new Color(255, 255, 255));
		titledashboard.setBounds(187, 82, 540, 34);
		dashboard.add(titledashboard);
		
		JLabel lbldashboards = new JLabel("DASHBOARD");
		lbldashboards.setForeground(new Color(255, 255, 255));
		lbldashboards.setHorizontalAlignment(SwingConstants.CENTER);
		lbldashboards.setFont(new Font("Comic Sans MS", Font.BOLD, 35));
		lbldashboards.setBackground(new Color(255, 255, 255));
		lbldashboards.setBounds(344, 2, 278, 82);
		dashboard.add(lbldashboards);
		
		JButton btnLogout = new JButton("LOGOUT");
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnLogout.setContentAreaFilled(false);
		btnLogout.setFocusable(false);
		btnLogout.setOpaque(false);
		btnLogout.setForeground(new Color(255, 255, 255));
		btnLogout.setHorizontalTextPosition(SwingConstants.CENTER);
		btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogout.setBorder(null);
		btnLogout.setBackground(new Color(240, 240, 240));
		btnLogout.setBounds(905, 86, 89, 23);
		dashboard.add(btnLogout);
		
		JLabel lblDatabaseStatus = new JLabel("DATABASE STATUS");
		lblDatabaseStatus.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		lblDatabaseStatus.setHorizontalAlignment(SwingConstants.CENTER);
		lblDatabaseStatus.setForeground(new Color(255, 255, 255));
		lblDatabaseStatus.setBounds(821, 137, 173, 34);
		dashboard.add(lblDatabaseStatus);
		
		DB_STATUS = new JLabel("");
		DB_STATUS.setOpaque(true);
		DB_STATUS.setBounds(811, 147, 23, 14);
		dashboard.add(DB_STATUS);
		
		layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 207, 1000, 393);
		contentPane.add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		pnladdproducts = new JPanel();
		pnladdproducts.setBackground(new Color(204, 204, 255));
		layeredPane.add(pnladdproducts, "name_56424903513930");
		pnladdproducts.setLayout(null);
		
		JPanel pnladdprocessors = new JPanel();
		pnladdprocessors.setBackground(new Color(255, 255, 255));
		pnladdprocessors.setBounds(90, 34, 259, 155);
		pnladdproducts.add(pnladdprocessors);
		pnladdprocessors.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("ADD PROCESSOR");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBackground(new Color(51, 0, 255));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(0, 0, 259, 14);
		pnladdprocessors.add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setBackground(new Color(0, 255, 153));
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_Processors().setVisible(true);
			}
		});
		label.setHorizontalTextPosition(SwingConstants.CENTER);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_Processor_858709 (1).png")));
		label.setBounds(0, 11, 259, 144);
		pnladdprocessors.add(label);
		
		JPanel pnladdram = new JPanel();
		pnladdram.setBackground(new Color(255, 255, 255));
		pnladdram.setBounds(398, 34, 259, 155);
		pnladdproducts.add(pnladdram);
		pnladdram.setLayout(null);
		
		JLabel lblAddRam = new JLabel("ADD RAM");
		lblAddRam.setBackground(new Color(51, 0, 255));
		lblAddRam.setForeground(new Color(255, 255, 255));
		lblAddRam.setOpaque(true);
		lblAddRam.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddRam.setBounds(0, 0, 259, 14);
		pnladdram.add(lblAddRam);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_Ram().setVisible(true);
			}
		});
		label_1.setHorizontalTextPosition(SwingConstants.CENTER);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_ram_2130484.png")));
		label_1.setBounds(0, 11, 259, 144);
		pnladdram.add(label_1);
		
		JPanel pnladdpsu = new JPanel();
		pnladdpsu.setBackground(new Color(255, 255, 255));
		pnladdpsu.setBounds(696, 34, 259, 155);
		pnladdproducts.add(pnladdpsu);
		pnladdpsu.setLayout(null);
		
		JLabel lblAddPsu = new JLabel("ADD PSU");
		lblAddPsu.setBackground(new Color(51, 0, 255));
		lblAddPsu.setForeground(new Color(255, 255, 255));
		lblAddPsu.setOpaque(true);
		lblAddPsu.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddPsu.setBounds(0, 0, 259, 14);
		pnladdpsu.add(lblAddPsu);
		
		JLabel label_2 = new JLabel("");
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_powersupply().setVisible(true);
			}
		});
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_electronics-14_808501.png")));
		label_2.setBounds(0, 11, 259, 144);
		pnladdpsu.add(label_2);
		
		JPanel pnladdgpu = new JPanel();
		pnladdgpu.setBackground(new Color(255, 255, 255));
		pnladdgpu.setBounds(90, 227, 259, 155);
		pnladdproducts.add(pnladdgpu);
		pnladdgpu.setLayout(null);
		
		JLabel lblAddGpu = new JLabel("ADD GPU");
		lblAddGpu.setBackground(new Color(51, 0, 255));
		lblAddGpu.setForeground(new Color(255, 255, 255));
		lblAddGpu.setOpaque(true);
		lblAddGpu.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddGpu.setBounds(0, 0, 259, 14);
		pnladdgpu.add(lblAddGpu);
		
		JLabel label_3 = new JLabel("");
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_Gpu().setVisible(true);
			}
		});
		label_3.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/graphic-card.png")));
		label_3.setHorizontalTextPosition(SwingConstants.CENTER);
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setBounds(0, 11, 259, 144);
		pnladdgpu.add(label_3);
		
		JPanel pnladdhdd = new JPanel();
		pnladdhdd.setBackground(new Color(255, 255, 255));
		pnladdhdd.setBounds(398, 227, 259, 155);
		pnladdproducts.add(pnladdhdd);
		pnladdhdd.setLayout(null);
		
		JLabel lblAddHdd = new JLabel("ADD HDD");
		lblAddHdd.setBackground(new Color(51, 0, 255));
		lblAddHdd.setOpaque(true);
		lblAddHdd.setForeground(new Color(255, 255, 255));
		lblAddHdd.setHorizontalTextPosition(SwingConstants.CENTER);
		lblAddHdd.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddHdd.setBounds(0, 0, 259, 14);
		pnladdhdd.add(lblAddHdd);
		
		JLabel label_4 = new JLabel("");
		label_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_Hdd().setVisible(true);
			}
		});
		label_4.setHorizontalTextPosition(SwingConstants.CENTER);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_HDD -2_51302.png")));
		label_4.setBackground(new Color(255, 255, 255));
		label_4.setBounds(0, 11, 259, 144);
		pnladdhdd.add(label_4);
		
		JPanel pnladdmotherbard = new JPanel();
		pnladdmotherbard.setBackground(new Color(255, 255, 255));
		pnladdmotherbard.setBounds(696, 227, 259, 155);
		pnladdproducts.add(pnladdmotherbard);
		pnladdmotherbard.setLayout(null);
		
		JLabel lblAddMotherboard = new JLabel("ADD MOTHERBOARD");
		lblAddMotherboard.setBackground(new Color(51, 0, 255));
		lblAddMotherboard.setOpaque(true);
		lblAddMotherboard.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddMotherboard.setForeground(new Color(255, 255, 255));
		lblAddMotherboard.setBounds(0, 0, 259, 14);
		pnladdmotherbard.add(lblAddMotherboard);
		
		JLabel label_5 = new JLabel("");
		label_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Add_MotherBoard().setVisible(true);
			}
		});
		label_5.setIcon(new ImageIcon(Dashboard.class.getResource("/icons/if_1_graphic_card_electronic_device_motherboard_smps_hardware_chip_1_998229.png")));
		label_5.setHorizontalTextPosition(SwingConstants.CENTER);
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setBounds(0, 11, 259, 144);
		pnladdmotherbard.add(label_5);
		
		pnlquickbill = new JPanel();
		pnlquickbill.setBackground(new Color(204, 204, 255));
		layeredPane.add(pnlquickbill, "name_56430246963452");
		pnlquickbill.setLayout(null);
		
		JLabel lblSelectCpu = new JLabel("SELECT CPU");
		lblSelectCpu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSelectCpu.setHorizontalTextPosition(SwingConstants.CENTER);
		lblSelectCpu.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectCpu.setBounds(64, 33, 247, 32);
		pnlquickbill.add(lblSelectCpu);
		
		cpu_combobox = new JComboBox();
		cpu_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fetch_row_processor = "select * from processors where Processor=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_processor);
					stmt.setString(1, (String)cpu_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_cpu.setText(set.getString("Price"));
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		});
		cpu_combobox.setBounds(64, 76, 247, 32);
		pnlquickbill.add(cpu_combobox);
		
		price_cpu = new JTextField();
		price_cpu.setBounds(139, 132, 86, 20);
		pnlquickbill.add(price_cpu);
		price_cpu.setColumns(10);
		
		JLabel lblSelectRam = new JLabel("SELECT RAM");
		lblSelectRam.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectRam.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSelectRam.setBounds(402, 33, 256, 26);
		pnlquickbill.add(lblSelectRam);
		
		ram_combobox = new JComboBox();
		ram_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fetch_row_ram = "select * from rams where RAM=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_ram);
					stmt.setString(1, (String)ram_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_ram.setText(set.getString("Price"));
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		});
		ram_combobox.setBounds(419, 76, 247, 32);
		pnlquickbill.add(ram_combobox);
		
		price_ram = new JTextField();
		price_ram.setBounds(498, 132, 86, 20);
		pnlquickbill.add(price_ram);
		price_ram.setColumns(10);
		
		JLabel lblSeelctPsu = new JLabel("SELECT PSU");
		lblSeelctPsu.setHorizontalAlignment(SwingConstants.CENTER);
		lblSeelctPsu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSeelctPsu.setBounds(794, 33, 162, 26);
		pnlquickbill.add(lblSeelctPsu);
		
		psu_combobox = new JComboBox();
		psu_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fetch_row_psu = "select * from powersupply where PowerSupply=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_psu);
					stmt.setString(1, (String)psu_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_psu.setText(set.getString("Price"));
					}
				} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		psu_combobox.setBounds(747, 76, 243, 32);
		pnlquickbill.add(psu_combobox);
		
		price_psu = new JTextField();
		price_psu.setBounds(828, 132, 86, 20);
		pnlquickbill.add(price_psu);
		price_psu.setColumns(10);
		
		JLabel lblSelectGpu = new JLabel("SELECT GPU");
		lblSelectGpu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSelectGpu.setHorizontalTextPosition(SwingConstants.CENTER);
		lblSelectGpu.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectGpu.setBounds(120, 184, 130, 32);
		pnlquickbill.add(lblSelectGpu);
		
		gpu_combobox = new JComboBox();
		gpu_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fetch_row_gpu = "select * from gpu where GPU=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_gpu);
					stmt.setString(1, (String)gpu_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_gpu.setText(set.getString("Price"));
					}
				} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		gpu_combobox.setBounds(64, 234, 247, 32);
		pnlquickbill.add(gpu_combobox);
		
		price_gpu = new JTextField();
		price_gpu.setBounds(139, 292, 86, 20);
		pnlquickbill.add(price_gpu);
		price_gpu.setColumns(10);
		
		JLabel lblSelectHdd = new JLabel("SELECT HDD");
		lblSelectHdd.setHorizontalTextPosition(SwingConstants.CENTER);
		lblSelectHdd.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectHdd.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSelectHdd.setBounds(472, 184, 149, 26);
		pnlquickbill.add(lblSelectHdd);
		
		hdd_combobox = new JComboBox();
		hdd_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fetch_row_hdd = "select * from harddrives  where HardDrives=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_hdd);
					stmt.setString(1, (String)hdd_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_hdd.setText(set.getString("Price"));
					}
				} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		hdd_combobox.setBounds(419, 234, 247, 32);
		pnlquickbill.add(hdd_combobox);
		
		price_hdd = new JTextField();
		price_hdd.setBounds(498, 292, 86, 20);
		pnlquickbill.add(price_hdd);
		price_hdd.setColumns(10);
		
		JLabel lblSelectMotherboard = new JLabel("SELECT MOTHERBOARD");
		lblSelectMotherboard.setHorizontalTextPosition(SwingConstants.CENTER);
		lblSelectMotherboard.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectMotherboard.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSelectMotherboard.setBounds(747, 184, 243, 26);
		pnlquickbill.add(lblSelectMotherboard);
		
		motheroard_combobox = new JComboBox();
		motheroard_combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fetch_row_motherboard = "select * from motherboards where MotherBoard=?";
					PreparedStatement stmt = conn.prepareStatement(fetch_row_motherboard);
					stmt.setString(1, (String)motheroard_combobox.getSelectedItem());
					ResultSet set = stmt.executeQuery();
					while(set.next()) {
						price_motherboard.setText(set.getString("Price"));
					}
				} catch (Exception ex	) {
					// TODO: handle exception
				}
			}
		});
		motheroard_combobox.setBounds(747, 234, 229, 32);
		pnlquickbill.add(motheroard_combobox);
		
		price_motherboard = new JTextField();
		price_motherboard.setBounds(828, 292, 86, 20);
		pnlquickbill.add(price_motherboard);
		price_motherboard.setColumns(10);
		
		JLabel lblTotalCost = new JLabel("TOTAL COST         $");
		lblTotalCost.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalCost.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblTotalCost.setBounds(313, 337, 184, 45);
		pnlquickbill.add(lblTotalCost);
		
		show_total = new JLabel("");
		show_total.setHorizontalAlignment(SwingConstants.CENTER);
		show_total.setFont(new Font("Tahoma", Font.BOLD, 18));
		show_total.setHorizontalTextPosition(SwingConstants.CENTER);
		show_total.setBounds(402, 337, 229, 45);
		pnlquickbill.add(show_total);
		
		JButton btncalculatetotal = new JButton("CALCULATE TOTAL");
		btncalculatetotal.setBackground(new Color(0, 0, 0));
		btncalculatetotal.setForeground(Color.WHITE);
		btncalculatetotal.setSelected(true);
		btncalculatetotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int one = Integer.parseInt(price_cpu.getText());
				int two = Integer.parseInt(price_gpu.getText());
				int three = Integer.parseInt(price_hdd.getText());
				int four = Integer.parseInt(price_motherboard.getText());
				int five = Integer.parseInt(price_psu.getText());
				int six = Integer.parseInt(price_ram.getText());
				
				String answer=String.valueOf(one+two+three+four+five+six);
				show_total.setText(answer);
				

			}
		});
		btncalculatetotal.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
		btncalculatetotal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btncalculatetotal.setBounds(85, 341, 215, 40);
		pnlquickbill.add(btncalculatetotal);
		
		JLabel lblNewLabel_2 = new JLabel("Price(in $)");
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblNewLabel_2.setBounds(64, 132, 89, 20);
		pnlquickbill.add(lblNewLabel_2);
		
		JLabel label_6 = new JLabel("Price(in $)");
		label_6.setFont(new Font("Segoe UI", Font.BOLD, 13));
		label_6.setBounds(423, 132, 89, 20);
		pnlquickbill.add(label_6);
		
		JLabel label_7 = new JLabel("Price(in $)");
		label_7.setFont(new Font("Segoe UI", Font.BOLD, 13));
		label_7.setBounds(747, 132, 89, 20);
		pnlquickbill.add(label_7);
		
		JLabel label_8 = new JLabel("Price(in $)");
		label_8.setFont(new Font("Segoe UI", Font.BOLD, 13));
		label_8.setBounds(64, 291, 89, 20);
		pnlquickbill.add(label_8);
		
		JLabel label_9 = new JLabel("Price(in $)");
		label_9.setFont(new Font("Segoe UI", Font.BOLD, 13));
		label_9.setBounds(419, 292, 89, 20);
		pnlquickbill.add(label_9);
		
		JLabel label_10 = new JLabel("Price(in $)");
		label_10.setFont(new Font("Segoe UI", Font.BOLD, 13));
		label_10.setBounds(747, 292, 89, 20);
		pnlquickbill.add(label_10);
		dropdownprocessor();
		dropdownram();
		dropdownmotherboard();
		dropdownhdd();
		dropdownpowersupply();
		dropdowngpu();
	}
}
