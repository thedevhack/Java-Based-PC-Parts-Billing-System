package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_Hdd extends JFrame {

	private JPanel contentPane;
	private JTextField txthddnme;
	private JTextField txthddprice;

	/**
	 * Launch the application.
	 */
	static Connection connection = null;
	public static void intialization() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Hdd frame = new Add_Hdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Hdd() {
		setBackground(new Color(0, 204, 255));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("HDD Name");
		lblNewLabel.setBounds(10, 58, 75, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblHddPrice = new JLabel("HDD Price");
		lblHddPrice.setBounds(10, 119, 64, 14);
		contentPane.add(lblHddPrice);
		
		txthddnme = new JTextField();
		txthddnme.setBounds(109, 55, 196, 20);
		contentPane.add(txthddnme);
		txthddnme.setColumns(10);
		
		txthddprice = new JTextField();
		txthddprice.setBounds(109, 116, 196, 20);
		contentPane.add(txthddprice);
		txthddprice.setColumns(10);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				intialization();
				try {
					String hdd_insert = "insert into harddrives values(?,?)";
					PreparedStatement statement = connection.prepareStatement(hdd_insert);
					statement.setString(1, txthddnme.getText());
					statement.setString(2, txthddprice.getText());
					int data_entered = statement.executeUpdate();
					if(data_entered > 0)
					{
						 JOptionPane.showMessageDialog(null,"Data Inserted Succesfully");
					}else {
						 JOptionPane.showMessageDialog(null,"Unable to insert data");

					}
					
					
					} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		btnSubmit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSubmit.setContentAreaFilled(false);
		btnSubmit.setBounds(166, 192, 89, 23);
		contentPane.add(btnSubmit);
	}
}
