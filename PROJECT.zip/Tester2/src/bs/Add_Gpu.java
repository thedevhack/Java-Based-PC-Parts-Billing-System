package bs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_Gpu extends JFrame {

	private JPanel contentPane;
	private JTextField txtgpuname;
	private JTextField txtgpuprice;

	/**
	 * Launch the application.
	 */
	static Connection connection = null;
	public static void intialization() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12260536","sql12260536","7jFLtbbdBj");
			//JOptionPane.showMessageDialog(null,"Connection Established");

		} catch (Exception e) {
			
			System.out.println("Error: " + e.getMessage());
			JOptionPane.showMessageDialog(null,"Connection Not Established");
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Gpu frame = new Add_Gpu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Gpu() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Gpu Name");
		lblNewLabel.setBounds(20, 66, 70, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblGpuPrice = new JLabel("Gpu Price");
		lblGpuPrice.setBounds(20, 112, 70, 14);
		contentPane.add(lblGpuPrice);
		
		txtgpuname = new JTextField();
		txtgpuname.setBounds(100, 63, 245, 20);
		contentPane.add(txtgpuname);
		txtgpuname.setColumns(10);
		
		txtgpuprice = new JTextField();
		txtgpuprice.setBounds(100, 109, 245, 20);
		contentPane.add(txtgpuprice);
		txtgpuprice.setColumns(10);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				intialization();
				try {
					String gpu_insert = "insert into gpu values(?,?)";
					PreparedStatement statement = connection.prepareStatement(gpu_insert);
					statement.setString(1, txtgpuname.getText());
					statement.setString(2, txtgpuprice.getText());
					int data_entered = statement.executeUpdate();
					if(data_entered > 0)
					{
						 JOptionPane.showMessageDialog(null,"Data Inserted Succesfully");
					}else {
						 JOptionPane.showMessageDialog(null,"Unable to insert data");

					}
					
					
					} catch (Exception ex) {
					// TODO: handle exception
				}
			}
		});
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBounds(168, 178, 101, 31);
		contentPane.add(btnNewButton);
	}

}
